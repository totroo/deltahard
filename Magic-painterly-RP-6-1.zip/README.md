# Magic Painterly Resource Pack

This RP is meant for use with the Magic Bukkit plugin:

https://github.com/elBukkit/MagicPlugin/wiki

## RP Credits

- 3D Artist: Dr00bles
- 2D Artists:
  - Dr00bles
  - eleazzaar
- Sound Effects:
  - Dr00bles
  - S-Toad (Flute samples for Ocarina)
  
## Notes on Spell Icons

Some of the spell icons contained in this plugin are used with permission from eleazzaar's Painterly Spell Icons pack:

http://opengameart.org/content/painterly-spell-icons-part-1

This pack is licensed under Creative Commons 3.0, any re-use needs to fall under that license and 
not the less-restrictive MIT license that covers the rest of the Magic source code and assets.
